SMART MISSION PORTAL - HOW TO PUT ONLINE (Netlify)

1. Go to app.netlify.com -> open your site -> "Deploys" tab.
2. Drag THIS ZIP (or the unzipped folder) onto the "Drag and drop your site folder here" box.
3. Wait until it says "Published".
4. Test: open   https://YOUR-SITE.netlify.app/.netlify/functions/portal?action=ping
   You must see:  {"ok":true,"storage":true}
   (If you see "Page not found", Netlify did not publish the netlify folder - see note below.)
5. Open your website -> tap the blue "NEW Smart Mission..." strip.
   Teachers fill the form -> Submit.  It is saved on the server and appears in the coordinator view.
6. Coordinator: tap "Coordinator view" -> enter PIN 3279 (stays remembered on your phone).

Change the PIN: Netlify -> Site configuration -> Environment variables -> add PORTAL_PIN = your new PIN -> redeploy.

Do NOT delete the folders "netlify" and "node_modules" - they are the server part.
Note: if drag-and-drop does not publish the server part, use "Add new site -> Import from Git" (GitHub) with these same files, or the Netlify CLI command:  netlify deploy --prod
