// Smart Mission School Observation Portal - server side (Netlify Function + Netlify Blobs)
// Coordinator PIN is checked HERE on the server. Change it in Netlify -> Site settings -> Environment variables (PORTAL_PIN)
// or edit the default below.
import { getStore } from "@netlify/blobs";

const PIN = String(process.env.PORTAL_PIN || "3279");
const PATH_OK = /^(submissions|reviews|replies)\/[A-Za-z0-9_-]{1,80}$/;
const COLS = ["submissions", "reviews", "replies"];

const json = (obj, status = 200) =>
  new Response(JSON.stringify(obj), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" },
  });
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

async function badPin() {
  await sleep(500); // slows down PIN guessing
  return json({ error: "Wrong PIN" });
}

export default async (req) => {
  try {
    const store = getStore({ name: "smhs-portal", consistency: "strong" });
    const url = new URL(req.url);

    if (req.method === "POST") {
      const raw = await req.text();
      if (raw.length > 400000) return json({ error: "Too large" }, 413);
      let b;
      try { b = JSON.parse(raw); } catch (e) { return json({ error: "Bad JSON" }, 400); }
      if (!PATH_OK.test(String(b.path || ""))) return json({ error: "Bad path" }, 400);
      const col = b.path.split("/")[0];
      if (col !== "submissions" && String(b.pin || "") !== PIN) return badPin();
      await store.setJSON(b.path, b.data);
      return json({ ok: true });
    }

    const q = url.searchParams, action = q.get("action"), pin = String(q.get("pin") || "");

    if (action === "ping") {
      await store.list({ prefix: "submissions/" }); // proves storage works
      return json({ ok: true, storage: true });
    }
    if (action === "check") {
      if (pin !== PIN) { await sleep(500); return json({ ok: false }); }
      return json({ ok: true });
    }
    if (action === "list") {
      const col = q.get("col");
      if (COLS.indexOf(col) < 0) return json({ error: "Bad collection" }, 400);
      if (pin !== PIN) return badPin();
      const { blobs } = await store.list({ prefix: col + "/" });
      const rows = (await Promise.all(blobs.slice(0, 1000).map(async (x) => {
        const data = await store.get(x.key, { type: "json" });
        return data ? { id: x.key.slice(col.length + 1), data } : null;
      }))).filter(Boolean);
      return json({ rows });
    }
    if (action === "get") {
      const path = String(q.get("path") || "");
      if (!PATH_OK.test(path)) return json({ error: "Bad path" }, 400);
      if (path.startsWith("reviews/") && pin !== PIN) return badPin();
      const data = await store.get(path, { type: "json" });
      return json({ exists: data != null, data: data == null ? null : data });
    }
    return json({ error: "Unknown action" }, 400);
  } catch (e) {
    return json({ error: "Server error: " + (e && e.message ? e.message : e) }, 500);
  }
};
